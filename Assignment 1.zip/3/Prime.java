import java.util.*;
public class Prime {
    public static void main(String[] arguments) {
        int n, i, c = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        n = sc.nextInt();
        for (i = 1; i <= n; i++) {
            if (n % i == 0) {
                c++;
            }
        }
        if (c == 2) {
            System.out.println(n + "Prime");
        }
        else  {
            System.out.println(n + "Composite");
        }
    }
}