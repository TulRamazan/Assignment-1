import java.util.*;
public class Average {
    public static void main(String[] arguments) {
        int count;
        double average = 0;
        System.out.println("Enter count of numbers: ");
        Scanner sc = new Scanner(System.in);
        count = sc.nextInt();
        int number, sum = 0;
        for (int i = 0; i < count; i++) {
            number = sc.nextInt();
            sum = sum + number;
        }
        average = (double) sum / count;
        System.out.println(" " + sum);
        System.out.println(" " + average);
    }
}